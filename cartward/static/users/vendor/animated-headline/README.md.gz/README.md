Animated Headlines
=========

A collection of animated headlines, with interchangeable words that replace one another through CSS transitions.

[Article on CodyHouse](http://codyhouse.co/gem/css-animated-headlines/)

[Demo](http://codyhouse.co/demo/animated-headlines/)
 
[Terms](http://codyhouse.co/terms/)
